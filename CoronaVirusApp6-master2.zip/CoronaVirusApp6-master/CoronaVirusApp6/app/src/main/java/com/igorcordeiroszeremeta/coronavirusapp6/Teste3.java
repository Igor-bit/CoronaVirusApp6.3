package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Teste3 extends AppCompatActivity {

    CheckBox conjuntivite;
    CheckBox dorDeCabeca;
    CheckBox perdaDePaladarOuOlfato;
    CheckBox erupcaoCutanea;
    Button botaoPaginaAnterior3;
    Button botaoProximo3;
    Button gravar3;
    TextView textoDoResultado3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste3);

        botaoProximo3 = findViewById(R.id.botaoProximo3);
        conjuntivite = findViewById(R.id.conjuntivite);
        dorDeCabeca = findViewById(R.id.dorDeCabeca);
        perdaDePaladarOuOlfato = findViewById(R.id.perdaDePaladarOuOlfato);
        erupcaoCutanea = findViewById(R.id.erupcaoCutanea);
        gravar3 = findViewById(R.id.gravar3);
        botaoPaginaAnterior3 = findViewById(R.id.botaoPaginaAnterior3);

        botaoProximo3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste4.class);
                startActivity(intent);
            }
        });

        botaoPaginaAnterior3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste2.class);
                startActivity(intent);
            }
        });

        gravar3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                textoDoResultado3 = findViewById(R.id.textoDoResultado3);
                int resultado3 = 0;
                if(erupcaoCutanea.isChecked()) {
                    resultado3 += 21;
                }
                if (conjuntivite.isChecked()) {
                    resultado3 += 21;
                }
                if (dorDeCabeca.isChecked()) {
                    resultado3 += 3;
                }
                if (perdaDePaladarOuOlfato.isChecked()) {
                    resultado3 += 1;
                }

                Intent intentRecebedora = getIntent();
                Bundle bundleRecebedor = intentRecebedora.getExtras();
                int resultado2 = bundleRecebedor.getInt("resultado2");
                resultado3 += resultado2;
                textoDoResultado3.setText(String.valueOf(resultado3));
                Intent intentEnviadora = new Intent(getApplicationContext(), Teste4.class);
                Bundle bundleEnviador = new Bundle();
                bundleEnviador.putInt("resultado3", resultado3);
                intentEnviadora.putExtras(bundleEnviador);
                startActivity(intentEnviadora);
                Intent intent = new Intent(getApplicationContext(), Teste3.class);
            }
        });
    }
}